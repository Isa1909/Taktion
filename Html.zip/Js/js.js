$(function() {
 let top = $('.top');
  
 $(window).scroll(function() {
   if($(this).scrollTop() > 1) {
    top.addClass('top_fixed');
   } else {
    top.removeClass('top_fixed');
   }
 });
});

$(function() {
 let top = $('.top');
 let topHeight = top.height(); // вычисляем высоту шапки
  
 $(window).scroll(function() {
   if($(this).scrollTop() > 1) {
    top.addClass('top_fixed');
    $('body').css({
       'paddingTop': topHeight+'px' // делаем отступ у body, равный высоте шапки
    });
   } else {
    top.removeClass('top_fixed');
    $('body').css({
     'paddingTop': 0 // удаляю отступ у body, равный высоте шапки
    })
   }
 });
});